A Pen created at CodePen.io. You can find this one at http://codepen.io/Almanza/pen/464c3064e380044e2c5002295d654a1e.

 Before I started formal fron end we 